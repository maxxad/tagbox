<?php
/**
 * The template for displaying answers
 *
 * @package DW Question & Answer
 * @since DW Question & Answer 1.4.3
 */

global $dwqa_general_settings;
$sort = isset( $_GET['sort'] ) ? esc_html( $_GET['sort'] ) : '';
$filter = isset( $_GET['filter'] ) ? esc_html( $_GET['filter'] ) : 'all';
?>

<div class="dwqa-question-filter">
	<div><?php _e( 'Filter:', 'dwqa' ); ?></div>
	<div><?php _e( 'A tag is a keyword or label that categorizes your question with other, similar questions. Using the right tags makes it easier for others to find and answer your question.', 'dwqa' ); ?></div>
	<div class="tab">
	<?php if ( !isset( $_GET['user'] ) ) : ?>
		<a href="<?php echo esc_url( add_query_arg( array( 'filter' => 'all' ) ) ) ?>" class="<?php echo 'all' == $filter ? 'active' : '' ?>"><?php _e( 'All', 'dwqa' ); ?></a>
		<a href="<?php echo esc_url( add_query_arg( array( 'filter' => 'popular' ) ) ) ?>" class="<?php echo 'popular' == $filter ? 'active' : '' ?>"><?php _e( 'Popular', 'dwqa' ); ?></a>
		<a href="<?php echo esc_url( add_query_arg( array( 'filter' => 'new' ) ) ) ?>" class="<?php echo 'new' == $filter ? 'active' : '' ?>"><?php _e( 'New', 'dwqa' ); ?></a>
		<a href="<?php echo esc_url( add_query_arg( array( 'filter' => 'name' ) ) ) ?>" class="<?php echo 'name' == $filter ? 'active' : '' ?>"><?php _e( 'Name', 'dwqa' ); ?></a>
	<?php endif; ?>
	</div>
</div>