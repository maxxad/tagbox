<?php
/**
 * The template for displaying tag archive pages
 *
 * @package DW Tag
 * @since DW Tag 1.4.3
 */
?>
<?php $tags_terms = dwqa_terms_tags(); ?> 
<div class="dwqa-tags-archive">
	<?php do_action( 'dwqa_before_tags_archive' ) ?>
	<div class="dwqa-tags-list tag-list">
		<?php do_action( 'dwqa_before_tags_list' ) ?>
		<?php if (is_array($tags_terms) && !empty($tags_terms)) : ?>
			<?php foreach ( $tags_terms as $term ) : $obj = get_term($term->term_id, 'dwqa-question_tag'); ?>
			<?php 
				global $dwqaSQL, $current_user;
				if (is_user_logged_in()) {
					$selectedFollower = $dwqaSQL->selectedFollower(get_current_user_id(),$term->term_id);
					$valFollower = ($selectedFollower) ? 'checked' : 'unchecked';
					$selectedSubscribe = $dwqaSQL->selectedSubscribe(get_current_user_id(),$term->term_id);
					$valSubscribe = ($selectedSubscribe) ? 'checked' : 'unchecked';
					$txtSubscribe = ($selectedSubscribe) ? 'unsubscribe' : 'subscribe';
					$email = $current_user->user_email;
				}
				$countFollow = $dwqaSQL->countTagFollow($term->term_id);
				$countSub = $dwqaSQL->countTagSubscribe($term->term_id);
			?>
			<div class="dwqa-tag-item">
				<div class="dwqa-tag-title">
					<a data-value="<?php echo $term->term_id; ?>" data-placement="bottom" data-toggle="popover" href="<?php echo get_term_link($term->slug, 'dwqa-question_tag'); ?>"><?php echo $term->name; ?></a> x <span class="item-multiplier-count"><?php echo dwqa_tags_count($term);?></span>
					<div id="popover-content-<?php echo $term->term_id; ?>" class="hide">
						<div class="dwqa-popup-tag-item">
							<div class="dwqa-tag-title">
							<?php if (is_user_logged_in()) : ?>
								<span data-value="<?php echo $term->term_id; ?>" id="tag-follower">
									<span class="colorFollower-<?php echo $term->term_id; ?> <?php echo $valFollower; ?>"><i class="fa fa-star-o" aria-hidden="true"></i></span>
								</span>
								<?php endif; ?>
								<a href="<?php echo get_term_link($obj); ?>"><?php echo $term->name; ?></a>
								<br \>
								<span class="item-multiplier-count"><?php echo dwqa_tags_count($obj);?> <?php echo _e('questions','dwqa');?>, <span class="countSub-<?php echo $term->term_id; ?>"><?php echo $countSub;?></span> <?php echo _e('subscribers','dwqa');?></span>
								<?php if (is_user_logged_in()) : ?>
								<span data-value="<?php echo $term->term_id; ?>" id="tag-subscribe">
									| <span class="txtSubscribe-<?php echo $term->term_id; ?>"><?php echo $txtSubscribe;?></span>
								</span>
								<div class="msgSubscribe-<?php echo $term->term_id; ?>" style="display:none;"><?php echo __('Confirmation email sent to '.$email.' - please check your inbox.'); ?></div>
								<input class="chkFollower-<?php echo $term->term_id; ?>" type="hidden" value="<?php echo $valFollower; ?>">
								<input class="chkSubscribe-<?php echo $term->term_id; ?>" type="hidden" value="<?php echo $valSubscribe; ?>">
								<?php endif; ?>
							</div>
							<div class="dwqa-tag-meta tag-meta-<?php echo $term->term_id; ?>">
								<div class="excerpt"><?php echo $term->description;?></div>
							</div>
							<div class="dwqa-ask">
								<span class="dwqa-answers-count">
									<a  href="#"><?php echo dwqa_tag_count_question($obj, 'today'); ?> asked today</a>, 
									<a href="#"><?php echo dwqa_tag_count_question($obj, 'week'); ?> this week</a>
								</span>
							</div>
						</div>
					</div>
				</div>
				<div class="dwqa-tag-meta">
					<div class="excerpt"><?php echo $term->description;?></div>
				</div>
				<div class="dwqa-ask">
					<span class="dwqa-answers-count">
						<a  href="#" title=""><?php echo dwqa_tag_count_question($obj, 'today'); ?> asked today</a>, 
						<a href="#" title=""><?php echo dwqa_tag_count_question($obj, 'week'); ?> this week</a>
					</span>
				</div>
			</div>
			<?php endforeach; ?>
		<?php else : ?>
			<?php dwqa_load_template( 'content', 'none' ) ?>
		<?php endif; ?>
		<?php do_action( 'dwqa_after_tags_list' ) ?>
	</div>
	<div class="dwqa-tags-footer">
		<?php terms_paginate_links(); ?>
	</div>

	<?php do_action( 'dwqa_after_tags_archive' ); ?>
</div>
