<?php
/**
 * The template for displaying single questions
 *
 * @package DW Question & Answer
 * @since DW Question & Answer 1.4.3
 */
 ?>

<?php do_action( 'dwqa_before_single_question_content' ); ?>
<div class="dwqa-question-item">
	<div class="dwqa-question-vote" data-nonce="<?php echo wp_create_nonce( '_dwqa_question_vote_nonce' ) ?>" data-post="<?php the_ID(); ?>">
		<span class="dwqa-vote-count"><?php echo dwqa_vote_count() ?></span>
		<a class="dwqa-vote dwqa-vote-up" href="#"><?php _e( 'Vote Up', 'dwqa' ); ?></a>
		<a class="dwqa-vote dwqa-vote-down" href="#"><?php _e( 'Vote Down', 'dwqa' ); ?></a>
	</div>
	<div class="dwqa-question-meta">
		<?php $user_id = get_post_field( 'post_author', get_the_ID() ) ? get_post_field( 'post_author', get_the_ID() ) : false ?>
		<?php printf( __( '<span><a href="%s">%s%s</a> %s asked %s ago</span>', 'dwqa' ), dwqa_get_author_link( $user_id ), get_avatar( $user_id, 48 ), get_the_author(),  dwqa_print_user_badge( $user_id ), human_time_diff( get_post_time( 'U', true ) ) ) ?>
		<span class="dwqa-question-actions"><?php dwqa_question_button_action() ?></span>
	</div>
	<div class="dwqa-question-content"><?php the_content(); ?></div>
	<?php do_action('dwqa_after_show_content_question', get_the_ID()); ?>
	<div class="dwqa-question-footer">
		<div class="dwqa-question-meta">
			
			<!-- start customize -->
				<?php 
					global $post;
					$tags_terms = get_the_terms( $post,  'dwqa-question_tag');
				?>
				<span class="dwqa-question-tag tag-list">
					<?php if (is_array($tags_terms) && !empty($tags_terms)) : ?>
						<?php $i=0; foreach ( $tags_terms as $term ) : $i++; ?>
						<?php 
							global $dwqaSQL, $current_user;
							if (is_user_logged_in()) {
								$selectedFollower = $dwqaSQL->selectedFollower(get_current_user_id(),$term->term_id);
								$valFollower = ($selectedFollower) ? 'checked' : 'unchecked';
								$selectedSubscribe = $dwqaSQL->selectedSubscribe(get_current_user_id(),$term->term_id);
								$valSubscribe = ($selectedSubscribe) ? 'checked' : 'unchecked';
								$txtSubscribe = ($selectedSubscribe) ? 'unsubscribe' : 'subscribe';
								$email = $current_user->user_email;
							}
							$countFollow = $dwqaSQL->countTagFollow($term->term_id);
							$countSub = $dwqaSQL->countTagSubscribe($term->term_id);
						?>
						<div class="dwqa-tag-item">
							<div class="dwqa-tag-title">
								<a data-value="<?php echo $term->term_id; ?>" data-placement="bottom" data-toggle="popover" href="<?php echo get_term_link($term); ?>"><?php echo $term->name; ?></a> 
								<div id="popover-content-<?php echo $term->term_id; ?>" class="popupover-content hide">
									<div class="tag-item">
										<div class="dwqa-tag-title">
											<?php if (is_user_logged_in()) : ?>
											<span data-value="<?php echo $term->term_id; ?>" id="tag-follower">
												<span class="colorFollower-<?php echo $term->term_id; ?> <?php echo $valFollower; ?>"><i class="fa fa-star-o" aria-hidden="true"></i></span>
											</span>
											<?php endif; ?>
											<a href="<?php echo get_term_link($term); ?>"><?php echo $term->name; ?></a>
											<br \>
											<span class="item-multiplier-count"><?php echo dwqa_tags_count($term);?> <?php echo _e('questions','dwqa');?>, <span class="countSub-<?php echo $term->term_id; ?>"><?php echo $countSub;?></span> <?php echo _e('subscribers','dwqa');?></span>
											<?php if (is_user_logged_in()) : ?>
											<span data-value="<?php echo $term->term_id; ?>" id="tag-subscribe">
												| <span class="txtSubscribe-<?php echo $term->term_id; ?>"><?php echo $txtSubscribe;?></span>
											</span>
											<div class="msgSubscribe-<?php echo $term->term_id; ?>" style="display:none;"><?php echo __('Confirmation email sent to '.$email.' - please check your inbox.'); ?></div>
											<input class="chkFollower-<?php echo $term->term_id; ?>" type="hidden" value="<?php echo $valFollower; ?>">
											<input class="chkSubscribe-<?php echo $term->term_id; ?>" type="hidden" value="<?php echo $valSubscribe; ?>">
											<?php endif; ?>
										</div>
										<div class="dwqa-tag-meta tag-meta-<?php echo $term->term_id; ?>">
											<div class="excerpt"><?php echo $term->description;?></div>
										</div>
										<div class="dwqa-ask">
											<span class="dwqa-answers-count">
												<a  href="#"><?php echo dwqa_tag_count_question($term, 'today'); ?> <?php echo _e('asked today','dwqa');?></a>, 
												<a href="#"><?php echo dwqa_tag_count_question($term, 'week'); ?> <?php echo _e('this week','dwqa');?></a>
											</span>
										</div>
									</div>
								</div>
							</div>
						</div>
						<?php endforeach; ?>
					<?php endif ?>
				</span>
			<!-- end customize -->
			<?php if ( dwqa_current_user_can( 'edit_question', get_the_ID() ) ) : ?>
				<?php if ( dwqa_is_enable_status() ) : ?>
				<span class="dwqa-question-status">
					<?php _e( 'This question is:', 'dwqa' ) ?>
					<select id="dwqa-question-status" data-nonce="<?php echo wp_create_nonce( '_dwqa_update_privacy_nonce' ) ?>" data-post="<?php the_ID(); ?>">
						<optgroup label="<?php _e( 'Status', 'dwqa' ); ?>">
							<option <?php selected( dwqa_question_status(), 'open' ) ?> value="open"><?php _e( 'Open', 'dwqa' ) ?></option>
							<option <?php selected( dwqa_question_status(), 'closed' ) ?> value="close"><?php _e( 'Closed', 'dwqa' ) ?></option>
							<option <?php selected( dwqa_question_status(), 'resolved' ) ?> value="resolved"><?php _e( 'Resolved', 'dwqa' ) ?></option>
						</optgroup>
					</select>
					</span>
				<?php endif; ?>
			<?php endif; ?>
		</div>
	</div>
	<?php do_action( 'dwqa_before_single_question_comment' ) ?>
	<?php comments_template(); ?>
	<?php do_action( 'dwqa_after_single_question_comment' ) ?>
</div>
<?php do_action( 'dwqa_after_single_question_content' ); ?>
