<?php
/**
 * The template for displaying question content
 *
 * @package DW Question & Answer
 * @since DW Question & Answer 1.4.3
 */

?>
<div class="<?php echo dwqa_post_class(); ?>">
	<div class="dwqa-question-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></div>
	<div class="dwqa-question-meta">
		<?php dwqa_question_print_status() ?>
		<?php
			global $post;
			$user_id = get_post_field( 'post_author', get_the_ID() ) ? get_post_field( 'post_author', get_the_ID() ) : false;
			$time = human_time_diff( get_post_time( 'U', true ) );
			$text = __( 'asked', 'dwqa' );
			$latest_answer = dwqa_get_latest_answer();
			if ( $latest_answer ) {
				$time = human_time_diff( strtotime( $latest_answer->post_date_gmt ) );
				$text = __( 'answered', 'dwqa' );
			}
		?>
		<?php printf( __( '<span><a href="%s">%s%s</a> %s %s ago</span>', 'dwqa' ), dwqa_get_author_link( $user_id ), get_avatar( $user_id, 48 ), get_the_author(), $text, $time ) ?>
		<?php echo get_the_term_list( get_the_ID(), 'dwqa-question_category', '<span class="dwqa-question-category">' . __( '&nbsp;&bull;&nbsp;', 'dwqa' ), ', ', '</span>' ); ?>

		<!-- tuantv edit here -->
		<?php 
			$tags_terms = get_the_terms( $post,  'dwqa-question_tag');
		?>
		<span class="tag-list">
			<?php if (is_array($tags_terms) && !empty($tags_terms)) : ?>
				<?php $i=0; foreach ( $tags_terms as $term ) : $i++; ?>
				<?php 
					global $dwqaSQL, $current_user;
					if (is_user_logged_in()) {
						$selectedFollower = $dwqaSQL->selectedFollower(get_current_user_id(),$term->term_id);
						$valFollower = ($selectedFollower) ? 'checked' : 'unchecked';
						$selectedSubscribe = $dwqaSQL->selectedSubscribe(get_current_user_id(),$term->term_id);
						$valSubscribe = ($selectedSubscribe) ? 'checked' : 'unchecked';
						$txtSubscribe = ($selectedSubscribe) ? 'unsubscribe' : 'subscribe';
						$email = $current_user->user_email;
					}
					$countFollow = $dwqaSQL->countTagFollow($term->term_id);
					$countSub = $dwqaSQL->countTagSubscribe($term->term_id);
				?>
				<div class="dwqa-tag-item">
					<div class="dwqa-tag-title">
						<a data-value="<?php echo $term->term_id; ?>" data-placement="bottom" data-toggle="popover" href="<?php echo get_term_link($term); ?>"><?php echo $term->name; ?></a> 
						<div id="popover-content-<?php echo $term->term_id; ?>" class="popupover-content hide">
							<div class="tag-item">
								<div class="dwqa-tag-title">
									<?php if (is_user_logged_in()) : ?>
									<span data-value="<?php echo $term->term_id; ?>" id="tag-follower">
										<span class="colorFollower-<?php echo $term->term_id; ?> <?php echo $valFollower; ?>"><i class="fa fa-star-o" aria-hidden="true"></i></span>
									</span>
									<?php endif; ?>
									<a href="<?php echo get_term_link($term); ?>"><?php echo $term->name; ?></a>
									<br \>
									<span class="item-multiplier-count"><?php echo dwqa_tags_count($term);?> <?php echo _e('questions','dwqa');?>, <span class="countSub-<?php echo $term->term_id; ?>"><?php echo $countSub;?></span> <?php echo _e('subscribers','dwqa');?></span>
									<?php if (is_user_logged_in()) : ?>
									<span data-value="<?php echo $term->term_id; ?>" id="tag-subscribe">
										| <span class="txtSubscribe-<?php echo $term->term_id; ?>"><?php echo $txtSubscribe;?></span>
									</span>
									<div class="msgSubscribe-<?php echo $term->term_id; ?>" style="display:none;"><?php echo __('Confirmation email sent to '.$email.' - please check your inbox.'); ?></div>
									<input class="chkFollower-<?php echo $term->term_id; ?>" type="hidden" value="<?php echo $valFollower; ?>">
									<input class="chkSubscribe-<?php echo $term->term_id; ?>" type="hidden" value="<?php echo $valSubscribe; ?>">
									<?php endif; ?>
								</div>
								<div class="dwqa-tag-meta tag-meta-<?php echo $term->term_id; ?>">
									<div class="excerpt"><?php echo $term->description;?></div>
								</div>
								<div class="dwqa-ask">
									<span class="dwqa-answers-count">
										<a  href="#"><?php echo dwqa_tag_count_question($term, 'today'); ?> <?php echo _e('asked today','dwqa');?></a>, 
										<a href="#"><?php echo dwqa_tag_count_question($term, 'week'); ?> <?php echo _e('this week','dwqa');?></a>
									</span>
								</div>
							</div>
						</div>
					</div>
				</div>
				<?php endforeach; ?>
			<?php endif ?>
		</span>
		<!-- tuantv end edit -->

	</div>
	<div class="dwqa-question-stats">
		<span class="dwqa-views-count">
			<?php $views_count = dwqa_question_views_count() ?>
			<?php printf( __( '<strong>%1$s</strong> views', 'dwqa' ), $views_count ); ?>
		</span>
		<span class="dwqa-answers-count">
			<?php $answers_count = dwqa_question_answers_count(); ?>
			<?php printf( __( '<strong>%1$s</strong> answers', 'dwqa' ), $answers_count ); ?>
		</span>
		<span class="dwqa-votes-count">
			<?php $vote_count = dwqa_vote_count() ?>
			<?php printf( __( '<strong>%1$s</strong> votes', 'dwqa' ), $vote_count ); ?>
		</span>
	</div>
</div>