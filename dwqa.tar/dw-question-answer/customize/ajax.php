<?php
/**
 *  DW Customize Ajax
 */
add_action( 'wp_ajax_dwqa_action_search_tags', 'dwqa_action_search_tags' );
add_action( 'wp_ajax_nopriv_dwqa_action_search_tags', 'dwqa_action_search_tags' );
function dwqa_action_search_tags() {
	$args = sanitize_text_field( $_POST['value'] );
	$json_data = apply_filters( '_dwqa_search_slug_tags_list', $args);
	wp_die( json_encode( $json_data ) );
}

add_action( 'wp_ajax_dwqa_action_hover_tags', 'dwqa_action_hover_tags' );
function dwqa_action_hover_tags() {
	$args = sanitize_text_field( $_POST['term_id'] );
	$json_data = apply_filters( '_dwqa_hover_slug_tags_list', $args);
	wp_die( json_encode( $json_data ) );
}

add_action( 'wp_ajax_dwqa_folower_slug_tags_list', 'dwqa_folower_slug_tags_list' );
function dwqa_folower_slug_tags_list() {
	global $wpdb, $dwqaSQL, $current_user;
	$json_data = array();
	if ( empty($_POST['term_id']) || empty($_POST['value'])) {
		$json_data['error'] = 'Something went wrong.';
	}
	$tag_id = sanitize_text_field( $_POST['term_id'] );
	$value = sanitize_text_field( $_POST['value'] );
	$user_id = get_current_user_id();
	
	$follower = ($value == "checked") ? '1' : '0';

	$dwqaSQL->updateFollower( $user_id, $tag_id, $follower );

	$json_data['count'] = $dwqaSQL->countTagFollow($tag_id);

	$sql = "SELECT tag_id FROM {$wpdb->prefix}user_reference WHERE user_id = {$user_id} AND follower = 1";
	$tags = $wpdb->get_results( $sql );
	$json_data['tags'] = '';
	if (isset($tags) && !empty($tags)) {
		$json_data['tags'] .= '<span class="widget-tag-list">';
		$i = 0;
		foreach ($tags as $tag) { $i++;
			$term = get_term_by('id', $tag->tag_id, 'dwqa-question_tag');
			if($term) {
				$json_data['tags'] .= '<div class="widget-tag-item item-'.$term->term_id.'">';
				$json_data['tags'] .= '	<div class="widget-tag-title">';
				$json_data['tags'] .= '		<a data-value="'.$term->term_id.'" href="'.get_term_link($term).'">'.$term->name.'</a>';
				$json_data['tags'] .= '	</div>';
				$json_data['tags'] .= '</div>';
			}
		}
		$json_data['tags'] .= '</span>';
	}

	$json_data['success'] = 'Follow success.';
	wp_die( json_encode( $json_data ) );
}

add_action( 'wp_ajax_dwqa_subscribe_slug_tags_list', 'dwqa_subscribe_slug_tags_list' );
function dwqa_subscribe_slug_tags_list() {
	global $wpdb, $dwqaSQL;
	$json_data = array();
	if ( empty($_POST['term_id']) || empty($_POST['value'])) {
		$json_data['error'] = 'Something went wrong.';
	}
	$tag_id = sanitize_text_field( $_POST['term_id'] );
	$value = sanitize_text_field( $_POST['value'] );
	$user_id = get_current_user_id();
	
	$subscribe = ($value == "checked") ? '1' : '0';

	$dwqaSQL->updateSubscribe( $user_id, $tag_id, $subscribe );

	global $current_user;
	// send mail
	if ($value == "checked") {
		$term = get_term( $tag_id, 'dwqa-question_tag' );
		$term_link = get_term_link( $term );
		$to = $current_user->user_email;
		$subject = 'You subscribed to a tag at SEBOverflow'; // tiny fix bug
		$body = 'You are now subscribed to the tag ' . $term->name . ' at SEBOverflow. You should now get e-mails whenever someone asks new questions with this tag. For more posts under this tag, visit ' . $term_link;
		$headers = array('Content-Type: text/html; charset=UTF-8','From: SEBOverflow &lt;seboverflow-support@seb.se');
		
		wp_mail( $to, $subject, $body, $headers );
	}
	
	$json_data['success'] = 'You are now subscribed to this tag.';
	wp_die( json_encode( $json_data ) );
}

?>
