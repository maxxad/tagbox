jQuery(function($){
    function reference(){   
        $(document).on('click', '#tag-follower', function() {
            var term_id = $(this).attr('data-value');
            if( $('.chkFollower-' + term_id).val() == 'unchecked' ) {
                $('.tag-list .chkFollower-' + term_id).each(function(){
                    $(this).val('checked');
                });
                $('.tag-list .colorFollower-' + term_id).each(function(){
                    $(this).addClass('checked');
                });
            } else {
                $('.tag-list .chkFollower-' + term_id).each(function(){
                    $(this).val('unchecked');
                });
                $('.tag-list .colorFollower-' + term_id).each(function(){
                    $(this).removeClass('checked');
                });
            }

            console.log($('.chkFollower-' + term_id).val() + ' --- chkFollower');
            $.ajax({
                url: dwqa_scripts.ajax_url,
                type: 'POST',
                dataType: 'json',
                data: {
                    action: 'dwqa_folower_slug_tags_list',
                    term_id: term_id,
                    value: $('.chkFollower-' + term_id).val()
                },
                success: function( data ) {
                    console.log( data );
                    $('.tag-list .countFollow-' + term_id).each(function(){
                        $(this).html('');
                        $(this).html(data['count']);
                    });
                    // tiny start add tag
                    if(!data['tags'].trim()==''){
                        if ($('.widget-tag-list').length) {
                            $('.widget-tag-list').html('');
                            $('.widget-tag-list').html(data['tags']);
                        }
                    }
                    // tiny end add tag
                }
            });
        });

        $(document).on('click', '#tag-subscribe', function() {
            var term_id = $(this).attr('data-value');
            if( $('.chkSubscribe-' + term_id).val() == 'unchecked' ) {
                $('.tag-list .chkSubscribe-' + term_id).each(function(){
                    $(this).val('checked');
                });
                $('.tag-list .txtSubscribe-' + term_id).each(function(){
                    $(this).text('unsubscribe');
                });
                $('.tag-list .msgSubscribe-' + term_id).each(function(){
                    $(this).show();
                });
                $('.tag-list .tag-meta-' + term_id).each(function(){
                    $(this).hide();
                });
            } else {
                $('.tag-list .chkSubscribe-' + term_id).each(function(){
                    $(this).val('unchecked');
                });
                $('.tag-list .txtSubscribe-' + term_id).each(function(){
                    $(this).text('subscribe');
                });
            }
            console.log($('.chkSubscribe-' + term_id).val() + ' --- chkSubscribe');
            $.ajax({
                url: dwqa_scripts.ajax_url,
                type: 'POST',
                dataType: 'json',
                data: {
                    action: 'dwqa_subscribe_slug_tags_list',
                    term_id: term_id,
                    value: $('.chkSubscribe-' + term_id).val()
                },
                success: function( data ) {
                    console.log( data );
                    setTimeout(function () {
                        $('.tag-list .msgSubscribe-' + term_id).each(function(){
                            $(this).hide();
                        });
                        $('.tag-list .tag-meta-' + term_id).each(function(){
                            $(this).show();
                        });
                    }, 1500);
                    
                }
            });
        });

    }
    reference();

    function tooltip(){
        $("[data-toggle=popover]").popover({ 
            trigger: "manual" , html: true, animation:false,
            content: function() {
                var dInput = $(this).attr('data-value');
                var content = '';
                // setTimeout(function () {
                //     $.ajax({
                //         url: dwqa_scripts.ajax_url,
                //         type: 'POST',
                //         dataType: 'json',
                //         data: {
                //             action: 'dwqa_action_hover_tags',
                //             term_id: dInput,
                //         },
                //         success: function( data ) {
                //             content = data;
                //             $('#popover-content-' + dInput).html( '' );
                //             $('#popover-content-' + dInput).append( data );
                //         }
                //     });
                // }, 500);
                return $('#popover-content-' + dInput).html();
            }

            }).on("mouseenter", function () {
                var _this = this;
                $(this).popover("show");
                $(".popover").on("mouseleave", function () {
                    $(_this).popover('hide');
                });
            }).on("mouseleave", function () {
                var _this = this;
                setTimeout(function () {
                    if (!$(".popover:hover").length) {
                        $(_this).popover("hide");
                    }
                }, 1);
        });
    }
    tooltip();
	// Search form
	$('#ajax_tags').on('input', function() {
        var dInput = this.value;
        console.log(dInput);
        $.ajax({
            url: dwqa_scripts.ajax_url,
            type: 'POST',
            dataType: 'json',
            data: {
                action: 'dwqa_action_search_tags',
                value: dInput,
            },
            success: function( data ) {
                console.log( data );
                $('.dwqa-tags-footer').html('');
                $('.dwqa-tags-list').html( data );
                tooltip();
            }
        });
    });
	
});