<?php
/**
 *  Plugin Name: DW Question Answer
 *  Description: A WordPress plugin was make by DesignWall.com to build an Question Answer system for support, asking and comunitcate with your customer
 *  Author: DesignWall
 *  Author URI: http://www.designwall.com
 *  Version: 1.5.1
 *  Text Domain: dwqa
 *  @since 1.4.0
 */

if ( !class_exists( 'DW_Customize' ) ) :

class DW_Customize {

	public function __construct() {
		$this->runSQL();
		$this->includes();
        $this->activate_hook();
		register_taxonomy_for_object_type( 'dwqa-question_tag', 'dwqa-question' );
		add_action( 'widgets_init', array( $this, 'widgets_init' ) );
		$this->shortcode = new DWQA_Customize_Shortcode();
	}

	public static function instance() {
		static $instance = null;

		if ( is_null( $instance ) ) {
			$instance = new self();
		} 

		return $instance;
	}

	function register_taxonomy(){
		// Create default category for dwqa question type when dwqa plugin is actived
	}

	public function widgets_init() {
		$widgets = array(
			'DWQA_Widgets_Favorite_Tag',
		);

		foreach( $widgets as $widget ) {
			register_widget( $widget );
		}
	}

	public function includes() {
		require_once DWQA_DIR . 'customize/ajax.php';
		require_once DWQA_DIR . 'customize/scripts.php';
		require_once DWQA_DIR . 'customize/class-customize-helper.php';
		require_once DWQA_DIR . 'customize/class-customize-hook.php';
		require_once DWQA_DIR . 'customize/class-customize-shortcode.php';
		require_once DWQA_DIR . 'customize/class-customize-functions.php';
		require_once DWQA_DIR . 'customize/class-customize-favorite-tag-widget.php';
	}

    public function activate_hook() {
		//Auto create tag page
		$options = get_option( 'dwqa_options' );

		if ( ! isset( $options['pages']['archive-tag'] ) || ( isset( $options['pages']['archive-tag'] ) && ! get_post( $options['pages']['archive-tag'] ) ) ) { 
			$args = array(
				'post_title' => __( 'DWQA Tags', 'dwqa' ),
				'post_type' => 'page',
				'post_status' => 'publish',
				'post_content'  => '[dwqa-list-tags]',
			);
			$tag_page = get_page_by_path( sanitize_title( $args['post_title'] ) );
			if ( ! $tag_page ) {
				$options['pages']['archive-tag'] = wp_insert_post( $args );
			} else {
				// Page exists
				$options['pages']['archive-tag'] = $tag_page->ID;
			}
		}

		// Valid page content to ensure shortcode was inserted
		$tags_page_content = get_post_field( 'post_content', $options['pages']['archive-tag'] );

		if ( strpos( $tags_page_content, '[dwqa-list-tags]' ) === false ) {
			$tags_page_content = str_replace( '[dwqa-submit-tag-form]', '', $tags_page_content );

			wp_update_post( array(
				'ID'			=> $options['pages']['archive-tag'],
				'post_content'	=> $tags_page_content . '[dwqa-list-tags]',
			) );
		}


		update_option( 'dwqa_options', $options );
	}
	
	public function runSQL(){
		global $wpdb;
		// check exist col in table
		$sql = "SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = '{$wpdb->prefix}terms' AND COLUMN_NAME = 'follower'";
		$result = $wpdb->query( $sql );
		if ( $result <= 0){
			$wpdb->query( "ALTER TABLE {$wpdb->prefix}terms ADD follower INT(20) NOT NULL DEFAULT 0" );
		}

		$sql = "SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = '{$wpdb->prefix}terms' AND COLUMN_NAME = 'created_date'";
		$result = $wpdb->query( $sql );
		if ( $result <= 0){
			$wpdb->query( "ALTER TABLE {$wpdb->prefix}terms ADD created_date datetime NOT NULL DEFAULT CURRENT_TIMESTAMP" );
		}

		// table user col follow & subcribe
		$sql = "
			SELECT `table_name`
			FROM information_schema.tables
			WHERE table_schema = '{$wpdb->dbname}'
			AND table_name = '{$wpdb->prefix}user_reference';
		";
		$result = $wpdb->query( $sql );
		if ( $result <= 0){
			$wpdb->query( "
			CREATE TABLE `{$wpdb->prefix}user_reference`  (
				`refer_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
				`user_id` bigint(20) NOT NULL,
				`tag_id` bigint(20) NOT NULL,
				`follower` int(20) NOT NULL DEFAULT 0,
				`subscribe` int(20) NOT NULL DEFAULT 0,
				`created_date` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP,
				`modified_date` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP,
				PRIMARY KEY (`refer_id`) USING BTREE
			  ) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;
			" );
		}
	}
}

function dwc() {
	return DW_Customize::instance();
}

$GLOBALS['dwc'] = dwc();

endif;