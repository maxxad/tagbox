<?php
/**
 *  DW Customize Functions
 */

function dwqa_terms_tags( $args = array() ) {
	
	$page_text = dwqa_is_front_page() ? 'page' : 'paged';
	$page = get_query_var( $page_text ) ? get_query_var( $page_text ) : 1;

	$filter = isset( $_GET['filter'] ) && !empty( $_GET['filter'] ) ? sanitize_text_field( $_GET['filter'] ) : 'all';
	$per_page = 10;
	$offset = ( $page - 1 ) * $per_page;

	// filter by tab
	switch ( $filter ) {
		case 'popular':
				global $wpdb; 
				$table = 'dwqa-question_tag';
				$sql = "SELECT DISTINCT wt.term_id, wt.name, wt.slug, wt.follower, wt.created_date, wtt.description FROM {$wpdb->prefix}terms wt";
				$sql .= " INNER JOIN {$wpdb->prefix}term_taxonomy wtt ON ( wt.term_id = wtt.term_id )";
				$sql .= " WHERE wtt.taxonomy = '{$table}' ORDER BY wt.follower DESC LIMIT {$offset}, {$per_page}";
				$terms = $wpdb->get_results($sql, OBJECT);
			break;
		case 'new':
				global $wpdb; 
				$table = 'dwqa-question_tag';
				$today = date('Y/m/d');
				$sql = "SELECT DISTINCT wt.term_id, wt.name, wt.slug, wt.follower, wt.created_date, wtt.description FROM {$wpdb->prefix}terms wt";
				$sql .= " INNER JOIN {$wpdb->prefix}term_taxonomy wtt ON ( wt.term_id = wtt.term_id )";
				$sql .= " WHERE wtt.taxonomy = '{$table}' AND DATE(wt.created_date) = '{$today}' LIMIT {$offset}, {$per_page}";
				$terms = $wpdb->get_results($sql, OBJECT);
			break;
		case 'name':
			$terms = get_terms( array(
				'taxonomy' => 'dwqa-question_tag',
				'orderby' => 'name', 
				'order' => 'DES',
				'number'        => $per_page,
				'offset'        => $offset,
				'hide_empty' => false,
			) );
			break;
		default:
			$terms = get_terms( array(
				'taxonomy' => 'dwqa-question_tag',
				'orderby' => 'name', 
				'order' => 'ASC',
				'number'        => $per_page,
				'offset'        => $offset,
				'hide_empty' => false,
			) );
			break;
	}
	return $terms;
}

function terms_paginate_links() {
	$filter = isset( $_GET['filter'] ) && !empty( $_GET['filter'] ) ? sanitize_text_field( $_GET['filter'] ) : 'all';
	$per_page = 10;
	$page_text = dwqa_is_front_page() ? 'page' : 'paged';
	$page = get_query_var( $page_text ) ? get_query_var( $page_text ) : 1;
	$big = 999999999;
	$offset = ( $page - 1 ) * $per_page;

	// filter by tab
	switch ( $filter ) {
		case 'popular':
				global $wpdb; 
				$table = 'dwqa-question_tag';
				$sql = "SELECT DISTINCT wt.term_id, wt.name, wt.slug, wt.follower, wt.created_date, wtt.description FROM {$wpdb->prefix}terms wt";
				$sql .= " INNER JOIN {$wpdb->prefix}term_taxonomy wtt ON ( wt.term_id = wtt.term_id )";
				$sql .= " WHERE wtt.taxonomy = '{$table}'";
				$terms = $wpdb->get_results($sql, OBJECT);
			break;
		case 'new':
				global $wpdb; 
				$table = 'dwqa-question_tag';
				$today = date('Y/m/d');
				$sql = "SELECT DISTINCT wt.term_id, wt.name, wt.slug, wt.follower, wt.created_date, wtt.description FROM {$wpdb->prefix}terms wt";
				$sql .= " INNER JOIN {$wpdb->prefix}term_taxonomy wtt ON ( wt.term_id = wtt.term_id )";
				$sql .= " WHERE wtt.taxonomy = '{$table}' AND DATE(wt.created_date) = '{$today}'";
				$terms = $wpdb->get_results($sql, OBJECT);
			break;
		case 'name':
			$terms = get_terms( array(
				'taxonomy' => 'dwqa-question_tag',
				'orderby' => 'name', 
				'order' => 'DES',
				'hide_empty' => false,
			) );
			break;
		default:
			$terms = get_terms( array(
				'taxonomy' => 'dwqa-question_tag',
				'hide_empty' => false,
			) );
			break;
	}

	$found_posts = count($terms);
	$max_num_pages = ceil($found_posts / $per_page);
	
	
	$args = array(
		'base' => '/dwqa-tags/%#%',
		'format' => '',
		'current' => $page,
		'total' => $max_num_pages // Here $max_num_pages is the properties of  new WP_Query() object . It is total number of pages. Is the result of $found_posts / $per_page
	);

	$paginate = paginate_links( $args );
	$paginate = str_replace( 'page-number', 'dwqa-page-number', $paginate );
	$paginate = str_replace( 'current', 'dwqa-current', $paginate );
	$paginate = str_replace( 'next', 'dwqa-next', $paginate );
	$paginate = str_replace( 'prev ', 'dwqa-prev ', $paginate );
	$paginate = str_replace( 'dots', 'dwqa-dots', $paginate );

	if ( $max_num_pages > 1 ) {
		echo '<div class="dwqa-pagination">';
		echo $paginate;
		echo '</div>';
	}
}

function dwqa_tags_count( $term ) {
	$postType = 'dwqa-question';
	$taxonomy = 'dwqa-question_tag';

    $query = new WP_Query([
        'posts_per_page' => -1,
        'post_type' => $postType,
        'tax_query' => [
            [
                'taxonomy' => $taxonomy,
                'terms' => $term,
                'field' => 'slug'
            ]
        ]
	]);
		
    $count = $query->found_posts;
	if ( $count > 0){ 
		return $count;
	} else { 
		return 0;
	}
}



function dwqa_tag_count_question( $term, $day_type = 'today' ){
	$postType = 'dwqa-question';
	$taxonomy = 'dwqa-question_tag';

	$current_day = date('Y/m/d');
	$today = date('Y/m/d', strtotime("+ 1 day"));
	$week = date('Y/m/d', strtotime('-7 days'));

	if ($day_type == 'today') {
		$query = new WP_Query([
			'posts_per_page' => -1,
			'post_type' => $postType,
			'date_query' => array(
				array(
					'after' => $current_day,
					'inclusive' => false,
				)
			),
			'tax_query' => [
				[
					'taxonomy' => $taxonomy,
					'terms' => $term,
					'field' => 'slug'
				]
			]
		]);
	} else {
		$query = new WP_Query([
			'posts_per_page' => -1,
			'post_type' => $postType,
			'date_query' => array(
				array(
					'after' => $week,
					'before' => $today,
					'inclusive' => false,
				)
			),
			'tax_query' => [
				[
					'taxonomy' => $taxonomy,
					'terms' => $term,
					'field' => 'slug'
				]
			]
		]);
	}
	$count = $query->found_posts;
	if ( $count > 0){ 
		return $count;
	} else { 
		return 0;
	}
}


?>