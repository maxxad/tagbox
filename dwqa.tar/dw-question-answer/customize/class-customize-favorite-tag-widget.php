<?php

class DWQA_Widgets_Favorite_Tag extends WP_Widget {
	/**
	 * Constructor
	 *
	 * @return void
	 **/
	function __construct() {
		$widget_ops = array( 'classname' => 'dwqa-widget dwqa-favorite', 'description' => __( 'Show a list of tags.', 'dwqa' ) );
		parent::__construct( 'dwqa-latest-tag', __( 'DWQA Favorite tags', 'dwqa' ), $widget_ops );
	}

	function widget( $args, $instance ) {
		extract( $args, EXTR_SKIP );
		$instance = wp_parse_args( $instance, array( 
			'title' => __( 'Your subscribed tags' , 'dwqa' ),
			'number' => 10,
		) );
		
		echo $before_widget;
		echo $before_title;
		echo $instance['title'];
		echo $after_title;
		
		global $wpdb, $current_user;
		$user_id = $current_user->ID;
		$sql = "SELECT tag_id FROM {$wpdb->prefix}user_reference WHERE user_id = {$user_id} AND subscribe = 1";
		$tags = $wpdb->get_results( $sql );

		if (isset($tags) && !empty($tags)) {
			echo '<span class="widget-tag-list">';
			$i = 0;
			foreach ($tags as $tag) { $i++;
				// if ($i <= $instance['number']) {
					$term = get_term_by('id', $tag->tag_id, 'dwqa-question_tag');
					if($term) {
						echo '<div class="widget-tag-item item-'.$term->term_id.'">';
						echo '	<div class="widget-tag-title">';
						echo '		<a data-value="'.$term->term_id.'" href="'.get_term_link($term).'">'.$term->name.'</a>';
						echo '	</div>';
						echo '</div>';
					}
				// }
				
			}
			echo '</span>';
		}
		wp_reset_query( );
		wp_reset_postdata( );
		echo $after_widget;
	}

	function update( $new_instance, $old_instance ) {

		// update logic goes here
		$updated_instance = $new_instance;
		return $updated_instance;
	}

	function form( $instance ) {
		$instance = wp_parse_args( $instance, array( 
			'title' => '',
			'number' => 5,
		) );

		?>
		<p><label for="<?php echo $this->get_field_id( 'title' ) ?>"><?php _e( 'Widget title', 'dwqa' ) ?></label>
		<input type="text" name="<?php echo $this->get_field_name( 'title' ) ?>" id="<?php echo $this->get_field_id( 'title' ) ?>" value="<?php echo $instance['title'] ?>" class="widefat">
		</p>
		<?php /* <p><label for="<?php echo $this->get_field_id( 'number' ) ?>"><?php _e( 'Number of posts', 'dwqa' ) ?></label>
		<input type="text" name="<?php echo $this->get_field_name( 'number' ) ?>" id="<?php echo $this->get_field_id( 'number' ) ?>" value="<?php echo $instance['number'] ?>" class="widefat">
		</p> */?>
		<?php
	}
}

?>
