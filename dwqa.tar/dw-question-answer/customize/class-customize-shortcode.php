<?php
/**
 *  DW Customize Shortcode
 */
class DWQA_Customize_Shortcode {
	private $shortcodes = array(
		'dwqa-list-tags',
	);

	public function __construct() {
		if ( ! defined( 'DWQA_DIR' ) ) {
			return false;
		}
		
		add_shortcode( 'dwqa-list-tags', array( $this, 'archive_tag') );
	
	}

	public function sanitize_output( $buffer ) {
		$search = array(
			'/\>[^\S ]+/s',  // strip whitespaces after tags, except space
			'/[^\S ]+\</s',  // strip whitespaces before tags, except space
			'/(\s)+/s',       // shorten multiple whitespace sequences
			"/\r/",
			"/\n/",
			"/\t/",
			'/<!--[^>]*>/s',
		);

		$replace = array(
			'>',
			'<',
			'\\1',
			'',
			'',
			'',
			'',
		);

		$buffer = preg_replace( $search, $replace, $buffer );
		return $buffer;
	}

	public function archive_tag( $atts = array() ) {
		global $dwqa, $script_version, $dwqa_sript_vars;
		ob_start();

		if ( isset( $atts['tag'] ) ) {
			$atts['tax_query'][] = array(
				'taxonomy' => 'dwqa-question_tag',
				'terms' => esc_html( $atts['tag'] ),
				'field' => 'slug'
			);
			unset( $atts['tag'] );
		}

		$dwqa->template->remove_all_filters( 'the_content' );
		dwqa()->filter->prepare_archive_posts( $atts );
		echo '<div class="dwqa-container" >';
		dwqa_load_template( 'archive', 'tag' );
		echo '</div>';
		$html = ob_get_contents();

		$dwqa->template->restore_all_filters( 'the_content' );

		ob_end_clean();
		wp_enqueue_script( 'jquery-ui-autocomplete' );
		//wp_enqueue_script( 'dwqa-tag-list', DWQA_URI . 'templates/assets/js/dwqa-questions-list.js', array( 'jquery', 'jquery-ui-autocomplete' ), $script_version, true );
		wp_localize_script( 'dwqa-tag-list', 'dwqa', $dwqa_sript_vars );
		return apply_filters( 'dwqa-shortcode-tag-list-content', $this->sanitize_output( $html ) );
	}

}

?>