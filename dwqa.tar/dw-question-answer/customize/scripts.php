<?php 

/**
 * Load Scripts
 *
 * Enqueues the required scripts.
 *
 * @since 1.0
 *
 * @return void
 */
function gwqa_load_scripts() {
    global $dwqa, $script_version;
    $js_dir         = DWQA_URI . 'customize/js/';
    $css_dir         = DWQA_URI . 'customize/css/';
    $scripts_footer = true;
    $script_version = $dwqa->get_last_update();

    // css
    wp_register_style( 'bootstrap', $css_dir . 'bootstrap.min.css' );
    wp_enqueue_style( 'bootstrap' );
    wp_register_style( 'font-awesome', $css_dir . 'font-awesome.min.css' );
	wp_enqueue_style( 'font-awesome' );
	
	// tiny start edit 
	wp_register_style( 'chosen', $css_dir . 'chosen.css' );
	wp_enqueue_style( 'chosen' );
	
	wp_register_script( 'chosen-jquery', $js_dir . 'chosen.js', array( 'jquery' ), $script_version, $scripts_footer );
	wp_enqueue_script( 'chosen-jquery' );
	// tiny end edit 

    wp_register_style( 'style', $css_dir . 'style.css' );
    wp_enqueue_style( 'style' );

    // js
    $localize_dwqa_ajax = array(
		'ajax_url'         => dwqa_get_ajax_url(),
		'ajax_nonce'       => wp_create_nonce( 'dwqa_ajax_nonce' ),
	);
    
    // Load AJAX scripts, if enabled.
    wp_enqueue_script( 'dwqa-tags-list', $js_dir . 'dwqa-tag-list.js', array( 'jquery' ), $script_version, $scripts_footer );
    wp_localize_script( 'dwqa-tags-list', 'dwqa_scripts', $localize_dwqa_ajax );


    wp_register_script( 'bootstrap_js', $js_dir . 'bootstrap.js', array( 'jquery' ), $script_version, false );
	wp_enqueue_script( 'bootstrap_js' );
}
add_action( 'wp_enqueue_scripts', 'gwqa_load_scripts' );


function dwqa_get_ajax_url( $query = array() ) {
	$scheme = defined( 'FORCE_SSL_ADMIN' ) && FORCE_SSL_ADMIN ? 'https' : 'admin';

	$current_url = dwqa_get_current_page_url();
	$ajax_url    = admin_url( 'admin-ajax.php', $scheme );

	if ( preg_match( '/^https/', $current_url ) && ! preg_match( '/^https/', $ajax_url ) ) {
		$ajax_url = preg_replace( '/^http/', 'https', $ajax_url );
	}

	if ( ! empty( $query ) ) {
		$ajax_url = add_query_arg( $query, $ajax_url );
	}

	return apply_filters( 'dwqa_ajax_url', $ajax_url );
}

/**
 * Get the current page URL.
 *
 * @since 1.0
 * @return string $current_url Current page URL.
 */
function dwqa_get_current_page_url() {

	global $wp;

	if ( get_option( 'permalink_structure' ) ) {
		$base = trailingslashit( home_url( $wp->request ) );
	} else {
		$base = add_query_arg( $wp->query_string, '', trailingslashit( home_url( $wp->request ) ) );
		$base = remove_query_arg( array( 'post_type', 'name' ), $base );
	}

	$scheme      = is_ssl() ? 'https' : 'http';
	$current_uri = set_url_scheme( $base, $scheme );

	if ( is_front_page() ) {
		$current_uri = home_url( '/' );
	}

	/**
	 * Filter the current page url
	 *
	 * @since 1.0
	 *
	 * @param string $current_uri
	 */
	return apply_filters( 'dwqa_get_current_page_url', $current_uri );

}
?>