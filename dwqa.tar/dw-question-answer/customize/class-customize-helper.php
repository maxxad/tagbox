<?php
/**
 *  Plugin Name: DW Question Answer
 *  Description: A WordPress plugin was make by DesignWall.com to build an Question Answer system for support, asking and comunitcate with your customer
 *  Author: DesignWall
 *  Author URI: http://www.designwall.com
 *  Version: 1.5.1
 *  Text Domain: dwqa
 *  @since 1.4.0
 */

if ( !class_exists( 'DW_Customize_Helper' ) ) :

class DW_Customize_Helper {

    public function __construct() {
    }
    
    public static function instance() {
		static $instance = null;

		if ( is_null( $instance ) ) {
			$instance = new self();
		} 

		return $instance;
    }
    
    public function existUserReference( $user_id, $tag_id, $follower = 0, $subscribe = 0 ) {
        global $wpdb; 
        $sql = "SELECT * FROM {$wpdb->prefix}user_reference WHERE `user_id` = '{$user_id}' AND `tag_id` = '{$tag_id}'";
        $result = $wpdb->query( $sql );
        if ( $result <= 0) {
            $sql = "INSERT INTO `{$wpdb->prefix}user_reference` ( user_id, tag_id , follower , subscribe ) VALUES ('{$user_id}', '{$tag_id}', '{$follower}', '{$subscribe}')";
            $result = $wpdb->query( $sql );
        }
        return true;
    }

    public function updateFollower( $user_id, $tag_id, $follower = 0 ) {
        global $wpdb; 
        if ( $this->existUserReference( $user_id, $tag_id, $follower, 0 ) ) {
            $sql = "UPDATE {$wpdb->prefix}user_reference SET follower = '{$follower}' WHERE `user_id` = '{$user_id}' AND `tag_id` = '{$tag_id}'";
            $result = $wpdb->query( $sql );
        }
        return true;
    }

    public function updateSubscribe( $user_id, $tag_id, $subscribe = 0 ) {
        global $wpdb; 
        if ( $this->existUserReference( $user_id, $tag_id, 0, $subscribe) ) {
            $sql = "UPDATE {$wpdb->prefix}user_reference SET subscribe = '{$subscribe}' WHERE `user_id` = '{$user_id}' AND `tag_id` = '{$tag_id}'";
            $result = $wpdb->query( $sql );
        }
        return true;
    }

    public function selectedSubscribe( $user_id, $tag_id ) {
        global $wpdb; 
        $sql = "SELECT * FROM {$wpdb->prefix}user_reference WHERE `user_id` = '{$user_id}' AND `tag_id` = '{$tag_id}' AND subscribe ='1'";
        $result = $wpdb->query( $sql );
        if ( $result > 0) {
            return true;
        }
        return false;
    }

    public function selectedFollower( $user_id, $tag_id ) {
        global $wpdb; 
        $sql = "SELECT * FROM {$wpdb->prefix}user_reference WHERE `user_id` = '{$user_id}' AND `tag_id` = '{$tag_id}' AND follower ='1'";
        $result = $wpdb->query( $sql );
        if ( $result > 0) {
            return true;
        }
        return false;
    }

    public function countTagFollow($tag_id) {
        global $wpdb; 
        $sql = "SELECT * FROM {$wpdb->prefix}user_reference WHERE tag_id = {$tag_id} AND follower = 1";
        $result = $wpdb->query( $sql );
        return $result;
    }

    public function countTagSubscribe($tag_id) {
        global $wpdb; 
        $sql = "SELECT * FROM {$wpdb->prefix}user_reference WHERE tag_id = {$tag_id} AND subscribe = 1";
        $result = $wpdb->query( $sql );
        return $result;
    }
}

function dwqaSQL() {
	return DW_Customize_Helper::instance();
}

$GLOBALS['dwqaSQL'] = dwqaSQL();

endif;