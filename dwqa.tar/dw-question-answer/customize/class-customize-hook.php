<?php
/**
 *  Plugin Name: DW Question Answer
 *  Description: A WordPress plugin was make by DesignWall.com to build an Question Answer system for support, asking and comunitcate with your customer
 *  Author: DesignWall
 *  Author URI: http://www.designwall.com
 *  Version: 1.5.1
 *  Text Domain: dwqa
 *  @since 1.4.0
 */

function dwqa_tags_search_form() {
	?>
	<form id="dwqa-search" class="dwqa-search">
		<input id="ajax_tags" type="text" placeholder="<?php _e( 'Filter by tag name', 'dwqa' ); ?>" name="ajax_tags" value="">
	</form>
	<?php
}
add_action( 'dwqa_before_tags_archive', 'dwqa_tags_search_form', 11 );

function dwqa_archive_tag_filter_layout() {
	dwqa_load_template( 'archive', 'tag-filter' );
}
add_action( 'dwqa_before_tags_archive', 'dwqa_archive_tag_filter_layout', 12 );


// ajax
function dwqa_hover_slug_tags_list( $args ) {
	global $wpdb; 
	$table = 'dwqa-question_tag';
	$sql = "SELECT DISTINCT wt.term_id, wt.name, wt.slug, wtt.description FROM {$wpdb->prefix}terms wt";
	$sql .= " INNER JOIN {$wpdb->prefix}term_taxonomy wtt ON ( wt.term_id = wtt.term_id )";
	$sql .= " WHERE wtt.taxonomy = '{$table}'";
	$sql .= " AND wt.term_id = '{$args}'";
	$terms = $wpdb->get_results($sql, OBJECT);
	$output = '';
	if ( count($terms) > 0 ) {
		foreach ($terms as $term) {
			$obj = get_term($term->term_id, $table);
			$output .= '
				<div class="tag-item">
					<div class="dwqa-question-title">
						<a href="'.get_term_link($term->slug, $table).'">'.$term->name.'</a> x <span class="item-multiplier-count">'.dwqa_tags_count($obj).'</span>
						
					</div>
					<div class="dwqa-question-meta">
						<div class="excerpt">'.$term->description.'</div>
					</div>
					<div class="dwqa-ask">
						<span class="dwqa-answers-count">
							<a href="#">'.dwqa_tag_count_question($obj, 'today').' asked today</a>, 
							<a href="#">'.dwqa_tag_count_question($obj, 'week').' asked week</a>
						</span>
					</div>
				</div>';
		}
	} else {
		$output = '<div class="dwqa-alert dwqa-alert-info">Sorry, but nothing matched your filter</div>';
	}
	
	return $output;
}
add_filter( '_dwqa_hover_slug_tags_list', 'dwqa_hover_slug_tags_list', 10, 3 );

// ajax
function dwqa_search_slug_tags_list( $args ) {
	global $wpdb; 
	$table = 'dwqa-question_tag';
	$sql = "SELECT DISTINCT wt.term_id, wt.name, wt.slug, wt.follower, wtt.description FROM {$wpdb->prefix}terms wt";
	$sql .= " INNER JOIN {$wpdb->prefix}term_taxonomy wtt ON ( wt.term_id = wtt.term_id )";
	$sql .= " WHERE wtt.taxonomy = '{$table}'";
	if ( !empty($args) ) {
		$sql .= " AND wt.name LIKE '{$args}%'";
	}
	$sql .= " LIMIT 0, 100";
	$terms = $wpdb->get_results($sql, OBJECT);
	$output = '';
	if ( count($terms) > 0 ) {
		foreach ($terms as $term) {
			$obj = get_term($term->term_id, $table);
			global $dwqaSQL, $current_user;
			if (is_user_logged_in()) {
				$selectedFollower = $dwqaSQL->selectedFollower(get_current_user_id(),$term->term_id);
				$valFollower = ($selectedFollower) ? 'checked' : 'unchecked';
				$selectedSubscribe = $dwqaSQL->selectedSubscribe(get_current_user_id(),$term->term_id);
				$valSubscribe = ($selectedSubscribe) ? 'checked' : 'unchecked';
				$txtSubscribe = ($selectedSubscribe) ? 'unsubscribe' : 'subscribe';
				$email = $current_user->user_email;
			}
			$countFollow = $dwqaSQL->countTagFollow($term->term_id);
			$countSub = $dwqaSQL->countTagSubscribe($term->term_id);
			$output .= '
				<div class="dwqa-tag-item">
					<div class="dwqa-tag-title">
						<a data-value="'.$term->term_id.'" data-placement="bottom" data-toggle="popover"  href="'.get_term_link($term->slug, $table).'">'.$term->name.'</a> x <span class="item-multiplier-count">'.dwqa_tags_count($obj).'</span>
						<div id="popover-content-'.$term->term_id.'" class="hide">
							<div class="dwqa-popup-tag-item">
								<div class="dwqa-tag-title">';
								if (is_user_logged_in()) :
			$output .= '			<span data-value="'.$term->term_id.'" id="tag-follower">
										<span class="colorFollower-'.$term->term_id.' '.$valFollower.'"><i class="fa fa-star-o" aria-hidden="true"></i></span>
									</span>';
								endif;
			$output .= 				'<a data-value="' .$term->term_id. '" data-placement="bottom" data-toggle="popover" href="'.get_term_link($term->slug, $table).'">'.$term->name.'</a>
									<span class="item-multiplier-count">'.dwqa_tags_count($obj).' questions, <span class="countFollow-'.$term->term_id.'">' . $countFollow. '</span> followers</span>';
								if (is_user_logged_in()) :
			$output .= 				'<span data-value="'.$term->term_id.'" id="tag-subscribe">
										<span class="txtSubscribe-'.$term->term_id.'">'.$txtSubscribe.'</span>
									</span>
									<div class="msgSubscribe-'.$term->term_id.'" style="display:none;">Confirmation email sent to '.$email.' - please check your inbox.</div>
									<input class="chkFollower-'.$term->term_id.'" type="hidden" value="'.$valFollower.'">
									<input class="chkSubscribe-'.$term->term_id.'" type="hidden" value="'.$valSubscribe.'">';
								endif;
			$output .=			'</div>
								<div class="dwqa-tag-meta tag-meta-'.$term->term_id.'">
									<div class="excerpt">'.$term->description.'</div>
								</div>
								<div class="dwqa-ask">
									<span class="dwqa-answers-count">
										<a href="#">'.dwqa_tag_count_question($obj, 'today').' asked today</a>, 
										<a href="#">'.dwqa_tag_count_question($obj, 'week').' asked week</a>
									</span>
								</div>
							</div>
						</div>
					</div>
					<div class="dwqa-tag-meta">
						<div class="excerpt">'.$term->description.'</div>
					</div>
					<div class="dwqa-ask">
						<span class="dwqa-answers-count">
							<a href="#">'.dwqa_tag_count_question($obj, 'today').' asked today</a>, 
							<a href="#">'.dwqa_tag_count_question($obj, 'week').' asked week</a>
						</span>
					</div>
				</div>';
		}
	} else {
		$output = '<div class="dwqa-alert dwqa-alert-info">Sorry, but nothing matched your filter</div>';
	}
	
	return $output;
}
add_filter( '_dwqa_search_slug_tags_list', 'dwqa_search_slug_tags_list', 10, 3 );



?>